// family-layout.ts

export type ID = string;

export type PersonInput = {
  id: ID;
  label: string;
  width?: number;
  height?: number;
};

export type UnionInput = {
  id: ID;

  /**
   * Marriage / relationship / partnership members.
   *
   * Usually 2 people, but the engine does not hard-code that.
   */
  partnerIds: ID[];

  /**
   * Children produced / attached to this union.
   */
  childIds: ID[];

  label?: string;
  width?: number;
  height?: number;
};

export type FamilyTreeInput = {
  persons: PersonInput[];
  unions: UnionInput[];
  rootId?: ID;
};

export type LayoutOptions = {
  rootId?: ID;

  personWidth: number;
  personHeight: number;
  unionWidth: number;
  unionHeight: number;

  rankGap: number;
  nodeGap: number;

  crossingPasses: number;
  optimizePasses: number;

  partnerWeight: number;
  childWeight: number;
  parentWeight: number;
  gravity: number;

  rootX: number;
  rootY: number;
};

export type LayoutNodeKind = "person" | "union";

export type LayoutNode = {
  key: string;
  kind: LayoutNodeKind;
  id: ID;
  label: string;

  rank: number;

  x: number;
  y: number;

  width: number;
  height: number;

  left: number;
  right: number;
  top: number;
  bottom: number;
};

export type LayoutEdgeType = "partner" | "child";

export type LayoutPoint = {
  x: number;
  y: number;
};

export type LayoutEdge = {
  id: string;
  type: LayoutEdgeType;
  from: string;
  to: string;
  points: LayoutPoint[];
};

export type LayoutBounds = {
  left: number;
  right: number;
  top: number;
  bottom: number;
  width: number;
  height: number;
};

export type LayoutResult = {
  nodes: LayoutNode[];
  edges: LayoutEdge[];
  bounds: LayoutBounds;
  warnings: string[];
  score: LayoutScore;
};

export type LayoutScore = {
  edgeLength: number;
  crossingsApprox: number;
  width: number;
  height: number;
};

type Atom = {
  key: string;
  kind: LayoutNodeKind;
  id: ID;
  label: string;

  width: number;
  height: number;

  rank: number;
  x: number;
  y: number;
};

type Graph = {
  persons: Map<ID, PersonInput>;
  unions: Map<ID, UnionInput>;

  atoms: Map<string, Atom>;

  personToPartnerUnions: Map<ID, ID[]>;
  personToParentUnions: Map<ID, ID[]>;

  warnings: string[];
};

const DEFAULT_OPTIONS: LayoutOptions = {
  personWidth: 120,
  personHeight: 48,
  unionWidth: 24,
  unionHeight: 24,

  rankGap: 110,
  nodeGap: 36,

  crossingPasses: 8,
  optimizePasses: 80,

  partnerWeight: 3.0,
  childWeight: 2.0,
  parentWeight: 1.25,
  gravity: 0.35,

  rootX: 0,
  rootY: 0,
};

function personKey(id: ID): string {
  return `p:${id}`;
}

function unionKey(id: ID): string {
  return `u:${id}`;
}

function avg(xs: number[]): number {
  if (xs.length === 0) return 0;
  return xs.reduce((a, b) => a + b, 0) / xs.length;
}

function median(xs: number[]): number {
  if (xs.length === 0) return 0;
  const sorted = [...xs].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  if (sorted.length % 2 === 1) return sorted[mid];
  return (sorted[mid - 1] + sorted[mid]) / 2;
}

function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

function unique<T>(items: T[]): T[] {
  return [...new Set(items)];
}

function weightedAverage(items: Array<{ value: number; weight: number }>): number {
  let total = 0;
  let weight = 0;

  for (const item of items) {
    total += item.value * item.weight;
    weight += item.weight;
  }

  if (weight === 0) return 0;
  return total / weight;
}

export class FamilyTreeLayoutEngine {
  layout(input: FamilyTreeInput, partialOptions: Partial<LayoutOptions> = {}): LayoutResult {
    const options: LayoutOptions = {
      ...DEFAULT_OPTIONS,
      ...partialOptions,
    };

    const graph = this.normalize(input, options);

    const rootId =
      options.rootId ??
      input.rootId ??
      input.persons[0]?.id;

    if (!rootId) {
      throw new Error("Cannot layout family tree without at least one person.");
    }

    if (!graph.persons.has(rootId)) {
      throw new Error(`Root person does not exist: ${rootId}`);
    }

    this.assignRanks(graph, rootId);
    let layers = this.buildInitialLayers(graph, rootId);

    for (let i = 0; i < options.crossingPasses; i++) {
      layers = this.reduceCrossings(graph, layers);
    }

    this.assignInitialPositions(graph, layers, options);

    for (let i = 0; i < options.optimizePasses; i++) {
      this.optimizePositions(graph, layers, options);
      this.resolveLayerOverlaps(graph, layers, options);
    }

    this.centerOnRoot(graph, rootId, options);
    this.assignYPositions(graph, options);

    const nodes = this.buildNodes(graph);
    const edges = this.buildEdges(graph);
    const bounds = this.computeBounds(nodes);
    const score = this.score(nodes, edges, bounds);

    return {
      nodes,
      edges,
      bounds,
      warnings: graph.warnings,
      score,
    };
  }

  private normalize(input: FamilyTreeInput, options: LayoutOptions): Graph {
    const warnings: string[] = [];

    const persons = new Map<ID, PersonInput>();
    const unions = new Map<ID, UnionInput>();
    const atoms = new Map<string, Atom>();

    const personToPartnerUnions = new Map<ID, ID[]>();
    const personToParentUnions = new Map<ID, ID[]>();

    for (const person of input.persons) {
      if (persons.has(person.id)) {
        warnings.push(`Duplicate person id ignored: ${person.id}`);
        continue;
      }

      persons.set(person.id, person);
      personToPartnerUnions.set(person.id, []);
      personToParentUnions.set(person.id, []);

      atoms.set(personKey(person.id), {
        key: personKey(person.id),
        kind: "person",
        id: person.id,
        label: person.label,
        width: person.width ?? options.personWidth,
        height: person.height ?? options.personHeight,
        rank: 0,
        x: 0,
        y: 0,
      });
    }

    for (const union of input.unions) {
      if (unions.has(union.id)) {
        warnings.push(`Duplicate union id ignored: ${union.id}`);
        continue;
      }

      const partnerIds = unique(union.partnerIds);
      const childIds = unique(union.childIds);

      for (const id of partnerIds) {
        if (!persons.has(id)) {
          warnings.push(`Union ${union.id} references missing partner person: ${id}`);
        }
      }

      for (const id of childIds) {
        if (!persons.has(id)) {
          warnings.push(`Union ${union.id} references missing child person: ${id}`);
        }
      }

      const cleanUnion: UnionInput = {
        ...union,
        partnerIds: partnerIds.filter((id) => persons.has(id)),
        childIds: childIds.filter((id) => persons.has(id)),
      };

      unions.set(cleanUnion.id, cleanUnion);

      atoms.set(unionKey(cleanUnion.id), {
        key: unionKey(cleanUnion.id),
        kind: "union",
        id: cleanUnion.id,
        label: cleanUnion.label ?? "",
        width: cleanUnion.width ?? options.unionWidth,
        height: cleanUnion.height ?? options.unionHeight,
        rank: 0,
        x: 0,
        y: 0,
      });

      for (const partnerId of cleanUnion.partnerIds) {
        personToPartnerUnions.get(partnerId)!.push(cleanUnion.id);
      }

      for (const childId of cleanUnion.childIds) {
        personToParentUnions.get(childId)!.push(cleanUnion.id);
      }
    }

    return {
      persons,
      unions,
      atoms,
      personToPartnerUnions,
      personToParentUnions,
      warnings,
    };
  }

  /**
   * Ranking rule:
   *
   * person partner union => same rank
   * union partner person => same rank
   * union child person   => union rank + 1
   * person parent union  => person rank - 1
   *
   * This lets the engine layout both ancestors and descendants around a root.
   */
  private assignRanks(graph: Graph, rootPersonId: ID): void {
    const ranks = new Map<string, number>();
    const queue: string[] = [];

    const setRank = (key: string, rank: number, reason: string) => {
      const existing = ranks.get(key);

      if (existing === undefined) {
        ranks.set(key, rank);
        queue.push(key);
        return;
      }

      if (existing !== rank) {
        graph.warnings.push(
          `Rank conflict for ${key}. Kept rank ${existing}, rejected rank ${rank}. Reason: ${reason}`,
        );
      }
    };

    setRank(personKey(rootPersonId), 0, "root");

    while (queue.length > 0) {
      const key = queue.shift()!;
      const atom = graph.atoms.get(key);
      if (!atom) continue;

      const rank = ranks.get(key)!;

      if (atom.kind === "person") {
        const partnerUnions = graph.personToPartnerUnions.get(atom.id) ?? [];
        const parentUnions = graph.personToParentUnions.get(atom.id) ?? [];

        for (const unionId of partnerUnions) {
          setRank(unionKey(unionId), rank, `person ${atom.id} is partner in union ${unionId}`);
        }

        for (const unionId of parentUnions) {
          setRank(unionKey(unionId), rank - 1, `person ${atom.id} is child of union ${unionId}`);
        }
      } else {
        const union = graph.unions.get(atom.id);
        if (!union) continue;

        for (const partnerId of union.partnerIds) {
          setRank(personKey(partnerId), rank, `union ${union.id} has partner ${partnerId}`);
        }

        for (const childId of union.childIds) {
          setRank(personKey(childId), rank + 1, `union ${union.id} has child ${childId}`);
        }
      }
    }

    /**
     * Handle disconnected components.
     *
     * They are placed in rank 0 initially.
     * The x optimizer and overlap resolver will push them apart.
     */
    for (const atom of graph.atoms.values()) {
      if (!ranks.has(atom.key)) {
        graph.warnings.push(`Disconnected node placed separately: ${atom.key}`);
        ranks.set(atom.key, 0);
      }
    }

    const minRank = Math.min(...ranks.values());

    for (const atom of graph.atoms.values()) {
      atom.rank = ranks.get(atom.key)! - minRank;
    }
  }

  private buildInitialLayers(graph: Graph, rootPersonId: ID): string[][] {
    const layers = new Map<number, string[]>();
    const order = this.breadthFirstOrder(graph, rootPersonId);

    for (const atom of graph.atoms.values()) {
      if (!layers.has(atom.rank)) {
        layers.set(atom.rank, []);
      }

      layers.get(atom.rank)!.push(atom.key);
    }

    const result: string[][] = [];

    const maxRank = Math.max(...layers.keys());

    for (let rank = 0; rank <= maxRank; rank++) {
      const layer = layers.get(rank) ?? [];

      layer.sort((a, b) => {
        const ao = order.get(a) ?? Number.MAX_SAFE_INTEGER;
        const bo = order.get(b) ?? Number.MAX_SAFE_INTEGER;

        if (ao !== bo) return ao - bo;
        return a.localeCompare(b);
      });

      result.push(layer);
    }

    return result;
  }

  private breadthFirstOrder(graph: Graph, rootPersonId: ID): Map<string, number> {
    const order = new Map<string, number>();
    const visited = new Set<string>();
    const queue: string[] = [personKey(rootPersonId)];

    let i = 0;

    while (queue.length > 0) {
      const key = queue.shift()!;
      if (visited.has(key)) continue;

      visited.add(key);
      order.set(key, i++);

      const atom = graph.atoms.get(key);
      if (!atom) continue;

      for (const next of this.neighbors(graph, atom)) {
        if (!visited.has(next)) {
          queue.push(next);
        }
      }
    }

    for (const atom of graph.atoms.values()) {
      if (!order.has(atom.key)) {
        order.set(atom.key, i++);
      }
    }

    return order;
  }

  private neighbors(graph: Graph, atom: Atom): string[] {
    const result: string[] = [];

    if (atom.kind === "person") {
      for (const unionId of graph.personToPartnerUnions.get(atom.id) ?? []) {
        result.push(unionKey(unionId));
      }

      for (const unionId of graph.personToParentUnions.get(atom.id) ?? []) {
        result.push(unionKey(unionId));
      }
    } else {
      const union = graph.unions.get(atom.id);
      if (!union) return result;

      for (const partnerId of union.partnerIds) {
        result.push(personKey(partnerId));
      }

      for (const childId of union.childIds) {
        result.push(personKey(childId));
      }
    }

    return result;
  }

  private reduceCrossings(graph: Graph, layers: string[][]): string[][] {
    let current = layers.map((layer) => [...layer]);

    for (let rank = 1; rank < current.length; rank++) {
      current[rank] = this.sortLayerByBarycenter(graph, current, rank, rank - 1);
    }

    for (let rank = current.length - 2; rank >= 0; rank--) {
      current[rank] = this.sortLayerByBarycenter(graph, current, rank, rank + 1);
    }

    return current;
  }

  private sortLayerByBarycenter(
    graph: Graph,
    layers: string[][],
    layerRank: number,
    anchorRank: number,
  ): string[] {
    const layer = [...layers[layerRank]];
    const anchor = layers[anchorRank] ?? [];

    const anchorOrder = new Map<string, number>();
    anchor.forEach((key, index) => anchorOrder.set(key, index));

    const bary = (key: string): number => {
      const atom = graph.atoms.get(key);
      if (!atom) return Number.MAX_SAFE_INTEGER;

      const positions: number[] = [];

      for (const neighborKey of this.neighbors(graph, atom)) {
        const neighbor = graph.atoms.get(neighborKey);
        if (!neighbor) continue;

        if (neighbor.rank === anchorRank) {
          const pos = anchorOrder.get(neighborKey);
          if (pos !== undefined) positions.push(pos);
        }
      }

      if (positions.length === 0) {
        return Number.MAX_SAFE_INTEGER;
      }

      return avg(positions);
    };

    layer.sort((a, b) => {
      const ab = bary(a);
      const bb = bary(b);

      if (ab !== bb) return ab - bb;
      return a.localeCompare(b);
    });

    return layer;
  }

  private assignInitialPositions(
    graph: Graph,
    layers: string[][],
    options: LayoutOptions,
  ): void {
    for (const layer of layers) {
      let cursor = 0;

      for (const key of layer) {
        const atom = graph.atoms.get(key)!;
        atom.x = cursor + atom.width / 2;
        cursor += atom.width + options.nodeGap;
      }

      if (layer.length > 0) {
        const atoms = layer.map((key) => graph.atoms.get(key)!);
        const left = Math.min(...atoms.map((a) => a.x - a.width / 2));
        const right = Math.max(...atoms.map((a) => a.x + a.width / 2));
        const center = (left + right) / 2;

        for (const atom of atoms) {
          atom.x -= center;
        }
      }
    }
  }

  private optimizePositions(
    graph: Graph,
    layers: string[][],
    options: LayoutOptions,
  ): void {
    const desired = new Map<string, number>();

    for (const atom of graph.atoms.values()) {
      desired.set(atom.key, atom.x);
    }

    for (const atom of graph.atoms.values()) {
      if (atom.kind === "union") {
        const union = graph.unions.get(atom.id);
        if (!union) continue;

        const partnerXs = union.partnerIds
          .map((id) => graph.atoms.get(personKey(id))?.x)
          .filter((x): x is number => x !== undefined);

        const childXs = union.childIds
          .map((id) => graph.atoms.get(personKey(id))?.x)
          .filter((x): x is number => x !== undefined);

        const targets: Array<{ value: number; weight: number }> = [];

        if (partnerXs.length > 0) {
          targets.push({
            value: avg(partnerXs),
            weight: options.partnerWeight,
          });
        }

        if (childXs.length > 0) {
          targets.push({
            value: median(childXs),
            weight: options.childWeight,
          });
        }

        if (targets.length > 0) {
          const target = weightedAverage(targets);
          desired.set(atom.key, lerp(atom.x, target, options.gravity));
        }
      }

      if (atom.kind === "person") {
        const parentUnions = graph.personToParentUnions.get(atom.id) ?? [];
        const partnerUnions = graph.personToPartnerUnions.get(atom.id) ?? [];

        const parentXs = parentUnions
          .map((id) => graph.atoms.get(unionKey(id))?.x)
          .filter((x): x is number => x !== undefined);

        const partnerUnionXs = partnerUnions
          .map((id) => graph.atoms.get(unionKey(id))?.x)
          .filter((x): x is number => x !== undefined);

        const targets: Array<{ value: number; weight: number }> = [];

        if (parentXs.length > 0) {
          targets.push({
            value: avg(parentXs),
            weight: options.parentWeight,
          });
        }

        if (partnerUnionXs.length > 0) {
          targets.push({
            value: avg(partnerUnionXs),
            weight: 0.35,
          });
        }

        if (targets.length > 0) {
          const target = weightedAverage(targets);
          desired.set(atom.key, lerp(atom.x, target, options.gravity * 0.4));
        }
      }
    }

    for (const [key, x] of desired) {
      const atom = graph.atoms.get(key);
      if (atom) atom.x = x;
    }
  }

  private resolveLayerOverlaps(
    graph: Graph,
    layers: string[][],
    options: LayoutOptions,
  ): void {
    for (const layer of layers) {
      if (layer.length <= 1) continue;

      const atoms = layer.map((key) => graph.atoms.get(key)!);
      const originalCenter = avg(atoms.map((a) => a.x));

      let previous: Atom | null = null;

      for (const atom of atoms) {
        if (!previous) {
          previous = atom;
          continue;
        }

        const minX =
          previous.x +
          previous.width / 2 +
          options.nodeGap +
          atom.width / 2;

        if (atom.x < minX) {
          atom.x = minX;
        }

        previous = atom;
      }

      const newCenter = avg(atoms.map((a) => a.x));
      const shift = originalCenter - newCenter;

      for (const atom of atoms) {
        atom.x += shift;
      }
    }
  }

  private centerOnRoot(
    graph: Graph,
    rootPersonId: ID,
    options: LayoutOptions,
  ): void {
    const root = graph.atoms.get(personKey(rootPersonId));
    if (!root) return;

    const shiftX = options.rootX - root.x;

    for (const atom of graph.atoms.values()) {
      atom.x += shiftX;
    }
  }

  private assignYPositions(graph: Graph, options: LayoutOptions): void {
    const rootRankY = 0;

    for (const atom of graph.atoms.values()) {
      atom.y = rootRankY + atom.rank * options.rankGap + options.rootY;
    }
  }

  private buildNodes(graph: Graph): LayoutNode[] {
    return [...graph.atoms.values()].map((atom) => ({
      key: atom.key,
      kind: atom.kind,
      id: atom.id,
      label: atom.label,

      rank: atom.rank,

      x: atom.x,
      y: atom.y,

      width: atom.width,
      height: atom.height,

      left: atom.x - atom.width / 2,
      right: atom.x + atom.width / 2,
      top: atom.y - atom.height / 2,
      bottom: atom.y + atom.height / 2,
    }));
  }

  private buildEdges(graph: Graph): LayoutEdge[] {
    const edges: LayoutEdge[] = [];

    for (const union of graph.unions.values()) {
      const unionAtom = graph.atoms.get(unionKey(union.id));
      if (!unionAtom) continue;

      for (const partnerId of union.partnerIds) {
        const personAtom = graph.atoms.get(personKey(partnerId));
        if (!personAtom) continue;

        const direction = unionAtom.x >= personAtom.x ? 1 : -1;

        edges.push({
          id: `partner:${partnerId}:${union.id}`,
          type: "partner",
          from: personAtom.key,
          to: unionAtom.key,
          points: [
            {
              x: personAtom.x + direction * (personAtom.width / 2),
              y: personAtom.y,
            },
            {
              x: unionAtom.x - direction * (unionAtom.width / 2),
              y: unionAtom.y,
            },
          ],
        });
      }

      for (const childId of union.childIds) {
        const childAtom = graph.atoms.get(personKey(childId));
        if (!childAtom) continue;

        const startY = unionAtom.y + unionAtom.height / 2;
        const endY = childAtom.y - childAtom.height / 2;
        const midY = (startY + endY) / 2;

        edges.push({
          id: `child:${union.id}:${childId}`,
          type: "child",
          from: unionAtom.key,
          to: childAtom.key,
          points: [
            {
              x: unionAtom.x,
              y: startY,
            },
            {
              x: unionAtom.x,
              y: midY,
            },
            {
              x: childAtom.x,
              y: midY,
            },
            {
              x: childAtom.x,
              y: endY,
            },
          ],
        });
      }
    }

    return edges;
  }

  private computeBounds(nodes: LayoutNode[]): LayoutBounds {
    if (nodes.length === 0) {
      return {
        left: 0,
        right: 0,
        top: 0,
        bottom: 0,
        width: 0,
        height: 0,
      };
    }

    const left = Math.min(...nodes.map((n) => n.left));
    const right = Math.max(...nodes.map((n) => n.right));
    const top = Math.min(...nodes.map((n) => n.top));
    const bottom = Math.max(...nodes.map((n) => n.bottom));

    return {
      left,
      right,
      top,
      bottom,
      width: right - left,
      height: bottom - top,
    };
  }

  private score(
    nodes: LayoutNode[],
    edges: LayoutEdge[],
    bounds: LayoutBounds,
  ): LayoutScore {
    const edgeLength = edges.reduce((total, edge) => {
      let length = 0;

      for (let i = 1; i < edge.points.length; i++) {
        const a = edge.points[i - 1];
        const b = edge.points[i];

        length += Math.abs(a.x - b.x) + Math.abs(a.y - b.y);
      }

      return total + length;
    }, 0);

    const crossingsApprox = this.approximateCrossings(edges);

    return {
      edgeLength,
      crossingsApprox,
      width: bounds.width,
      height: bounds.height,
    };
  }

  private approximateCrossings(edges: LayoutEdge[]): number {
    let count = 0;

    const segments = edges.flatMap((edge) => {
      const result: Array<{
        edgeId: string;
        a: LayoutPoint;
        b: LayoutPoint;
      }> = [];

      for (let i = 1; i < edge.points.length; i++) {
        result.push({
          edgeId: edge.id,
          a: edge.points[i - 1],
          b: edge.points[i],
        });
      }

      return result;
    });

    for (let i = 0; i < segments.length; i++) {
      for (let j = i + 1; j < segments.length; j++) {
        const a = segments[i];
        const b = segments[j];

        if (a.edgeId === b.edgeId) continue;

        if (segmentsIntersect(a.a, a.b, b.a, b.b)) {
          count++;
        }
      }
    }

    return count;
  }
}

function segmentsIntersect(
  a: LayoutPoint,
  b: LayoutPoint,
  c: LayoutPoint,
  d: LayoutPoint,
): boolean {
  const ccw = (p1: LayoutPoint, p2: LayoutPoint, p3: LayoutPoint) => {
    return (p3.y - p1.y) * (p2.x - p1.x) > (p2.y - p1.y) * (p3.x - p1.x);
  };

  return ccw(a, c, d) !== ccw(b, c, d) && ccw(a, b, c) !== ccw(a, b, d);
}
